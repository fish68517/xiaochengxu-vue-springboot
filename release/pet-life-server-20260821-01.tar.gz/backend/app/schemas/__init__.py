"""Pydantic schemas。"""
